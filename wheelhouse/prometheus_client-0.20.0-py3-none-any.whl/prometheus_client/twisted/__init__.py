from ._exposition import MetricsResource

__all__ = ['MetricsResource']
