from .docx2txt import process
from .docx2txt import process_args

VERSION = '0.9'
